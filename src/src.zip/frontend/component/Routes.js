import { Router, Route, hashHistory } from 'react-router';
import ReactDOM from 'react-dom';
import App from './App';
import Inputform from './Inputform';
import React from 'react';
import Table from './Table';
import Student from './student.js';
const routes = (
  <Router history={hashHistory}>
    <Route path='/' component={App}>
    <Route path='/Inputform' component={Inputform}/>
    <Route path='/Table' component={Table}/>
    <Route path='/Student' component={Student} />
  </Route>
</Router>
)
export default routes;
