import React, { Component } from 'react';
import { AppBar, Checkbox, IconButton, Button} from 'react-toolbox';
import {IconMenu, MenuItem, MenuDivider } from 'react-toolbox/lib/menu';
import { Layout, NavDrawer, Panel, Sidebar } from 'react-toolbox';
import Navigation from 'react-toolbox/lib/navigation';
import Input from 'react-toolbox/lib/input';
import PouchDB from 'pouchdb-browser' ;
import { Card, CardMedia, CardTitle, CardText, CardActions } from 'react-toolbox/lib/card';
var db = new PouchDB('dbname');

class Inputform extends React.Component {
        constructor(props) {
          super(props);
            this.state = {
                  _id: '' ,  name: '', phone: '', email: ''
                };
                this.baseState = this.state ;
            }
  handleClick = () => {
    console.log(this.state);
    this.setState(this.baseState);
    this.state._id = new Date().toISOString();
    if(this.state.name === ''){console.log('EMptyinput');}
    else {
    db.put(this.state);
}
  };

  resetForm = () => {
      this.setState(this.baseState);
  }
  handleChange = (name, value) => {
    this.setState({...this.state, [name]: value});
  };

  render () {
    return (<div style={{ flex: 1, overflowX: 'auto', margin: '5% 10% 10% 20%' }}>
      
      <section>
        <Input type='text' label='Name' name='name' icon='person' value={this.state.name} onChange={this.handleChange.bind(this, 'name')} />
        <Input type='email' label='Email address' icon='email' value={this.state.email} onChange={this.handleChange.bind(this, 'email')} />
        <Input type='tel' label='Phone' name='phone' icon='phone' value={this.state.phone} onChange={this.handleChange.bind(this, 'phone')} />
        <div style={{ flex: 1, overflowX: 'auto', padding: '1.8rem' }}>
        <Button  label='Add Student' raised primary onClick={this.handleClick} />
        <Button  label='Reset' onClick={this.resetForm} accent raised/>
        </div>
      </section>
      </div>
    );
  }
}
export default Inputform;
